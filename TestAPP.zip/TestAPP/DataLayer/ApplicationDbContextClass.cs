﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace testlocus.Models
{
    public class ApplicationDbContextClass: DbContext
    {
        public ApplicationDbContextClass(DbContextOptions<ApplicationDbContextClass> options):base(options)
        {

        }

        public DbSet<MyUsers> TestUsers2 { get; set; }
    }
}
